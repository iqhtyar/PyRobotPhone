import openai

# Inisialisasi kunci API OpenAI
openai.api_key = 'YOUR_API_KEY'

# Fungsi untuk berkomunikasi dengan OpenAI
def ask_openai(question):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=question,
        max_tokens=100
    )
    return response.choices[0].text.strip()

# Fungsi untuk mengirim perintah ke robot melalui serial
def send_command_to_robot(command):
    # Implementasi pengiriman command ke robot melalui koneksi serial
    pass

# Contoh penggunaan
user_question = "Apa nama robot ini?"
openai_response = ask_openai(user_question)

# Kirim jawaban dari OpenAI ke robot
send_command_to_robot(openai_response)
