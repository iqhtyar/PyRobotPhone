import serial

# Buka port serial
ser = serial.Serial("/dev/ttyUSB0", 9600)

# Deklarasi variabel
kiri = 0
kanan = 0

# Loop utama
while True:

    # Baca data dari serial port
    data = ser.readline().decode("utf-8")

    # Jika data adalah "maju", gerakkan motor maju
    if data == "maju":
        kiri = 100
        kanan = 100

    # Jika data adalah "mundur", gerakkan motor mundur
    elif data == "mundur":
        kiri = -100
        kanan = -100

    # Jika data adalah "belok kiri", gerakkan motor kiri
    elif data == "belok kiri":
        kiri = 100
        kanan = 0

    # Jika data adalah "belok kanan", gerakkan motor kanan
    elif data == "belok kanan":
        kiri = 0
        kanan = 100

    # Jika data adalah "stop", hentikan motor
    elif data == "stop":
        kiri = 0
        kanan = 0

    # Set kecepatan motor
    ser.write(str(kiri) + " " + str(kanan) + "\n")

