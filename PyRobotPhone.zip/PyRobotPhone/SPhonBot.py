import serial
import pygame
import speech_recognition as sr

# Buka port serial
ser = serial.Serial("/dev/ttyUSB0", 9600)

# Deklarasi variabel
kiri = 0
kanan = 0

# Inisialisasi pygame
pygame.init()

# Buat layar
layar = pygame.display.set_mode((640, 480))

# Tampilkan gambar avatar gif
gambar = pygame.image.load("avatar.gif")

# Loop utama
while True:

    # Baca data dari serial port
    data = ser.readline().decode("utf-8")

    # Jika data adalah "maju", gerakkan motor maju
    if data == "maju":
        kiri = 100
        kanan = 100

    # Jika data adalah "mundur", gerakkan motor mundur
    elif data == "mundur":
        kiri = -100
        kanan = -100

    # Jika data adalah "belok kiri", gerakkan motor kiri
    elif data == "belok kiri":
        kiri = 100
        kanan = 0

    # Jika data adalah "belok kanan", gerakkan motor kanan
    elif data == "stop":
        kiri = 0
        kanan = 0

    # Update layar
    pygame.display.update()

    # Deteksi suara
    recognizer = sr.Recognizer()
    with sr.Microphone() as source:
        audio = recognizer.listen(source)

    # Proses suara
    try:
        hasil = recognizer.recognize_google(audio)
        print(hasil)

        # Kontrol robot dengan suara
        if hasil == "maju":
            kiri = 100
            kanan = 100
        elif hasil == "mundur":
            kiri = -100
            kanan = -100
        elif hasil == "belok kiri":
            kiri = 100
            kanan = 0
        elif hasil == "belok kanan":
            kiri = 0
            kanan = 100
        elif hasil == "stop":
            kiri = 0
            kanan = 0

    except:
        pass

    # Set kecepatan motor
    ser.write(str(kiri) + " " + str(kanan) + "\n")

