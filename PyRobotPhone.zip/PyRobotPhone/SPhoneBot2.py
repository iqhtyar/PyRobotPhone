from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.image import Image
from kivy.clock import Clock

class RobotApp(App):
    def build(self):
        layout = BoxLayout(orientation='vertical')

        # Ganti 'your_gif.gif' dengan nama file GIF Anda
        gif_image = Image(source='your_gif.gif', anim_delay=1 / 30.0)
        layout.add_widget(gif_image)

        # Fungsi untuk mengubah gambar GIF
        def update_gif(dt):
            gif_image.reload()

        # Pembaruan gambar GIF setiap 1/30 detik (sesuaikan sesuai kebutuhan)
        Clock.schedule_interval(update_gif, 1 / 30.0)

        return layout

if __name__ == '__main__':
    RobotApp().run()
