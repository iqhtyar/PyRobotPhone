import speech_recognition as sr

# Fungsi untuk mendengarkan perintah suara
def listen_command():
    recognizer = sr.Recognizer()
    
    with sr.Microphone() as source:
        print("Silakan ucapkan perintah...")
        audio = recognizer.listen(source)

    try:
        command = recognizer.recognize_google(audio).lower()
        print(f"Perintah: {command}")
        return command
    except sr.UnknownValueError:
        print("Maaf, tidak dapat mengenali perintah.")
        return None

# Fungsi untuk mengubah perintah suara menjadi gerakan robot
def interpret_command(command):
    if "majukan" in command:
        send_forward_command_to_robot()
    elif "mundur" in command:
        send_backward_command_to_robot()
    elif "kiri" in command:
        send_left_command_to_robot()
    elif "kanan" in command:
        send_right_command_to_robot()
    else:
        print("Perintah tidak dikenali.")

# Implementasikan fungsi-fungsi kendali motor sesuai kebutuhan
def send_forward_command_to_robot():
    # Implementasikan perintah maju
    pass

def send_backward_command_to_robot():
    # Implementasikan perintah mundur
    pass

def send_left_command_to_robot():
    # Implementasikan perintah belok kiri
    pass

def send_right_command_to_robot():
    # Implementasikan perintah belok kanan
    pass

# Loop untuk mendengarkan dan menanggapi perintah suara
while True:
    user_command = listen_command()
    
    if user_command:
        interpret_command(user_command)
