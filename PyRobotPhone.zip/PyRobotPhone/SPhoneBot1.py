import serial
import time

ser = serial.Serial('COMx', 9600)  # Ganti 'COMx' dengan port serial yang sesuai

def move_forward():
    ser.write(b'F')  # Mengirim karakter 'F' untuk maju

def move_backward():
    ser.write(b'B')  # Mengirim karakter 'B' untuk mundur

def turn_left():
    ser.write(b'L')  # Mengirim karakter 'L' untuk belok kiri

def turn_right():
    ser.write(b'R')  # Mengirim karakter 'R' untuk belok kanan

def stop():
    ser.write(b'S')  # Mengirim karakter 'S' untuk berhenti

# Contoh penggunaan
move_forward()
time.sleep(2)  # Tunggu selama 2 detik
stop()

# Tutup koneksi serial
ser.close()
