import openai

# Inisialisasi kunci API OpenAI
openai.api_key = 'YOUR_API_KEY'

# Fungsi untuk mengirim pertanyaan atau perintah ke OpenAI
def ask_openai(question):
    response = openai.Completion.create(
        engine="text-davinci-003",
        prompt=question,
        max_tokens=100
    )
    return response.choices[0].text.strip()

# Fungsi untuk berkomunikasi dengan pengguna melalui suara
def communicate_with_user():
    while True:
        user_command = listen_command()  # Menggunakan fungsi dari contoh sebelumnya
        if user_command:
            openai_response = ask_openai(user_command)
            speak_response(openai_response)  # Implementasikan fungsi untuk mengeluarkan suara

# Implementasikan fungsi speak_response() untuk mengeluarkan suara ke pengguna
def speak_response(response):
    # Implementasikan metode untuk mengeluarkan suara menggunakan speaker atau sistem audio
    pass

# Panggil fungsi utama
communicate_with_user()
