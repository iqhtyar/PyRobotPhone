import serial

# Buka koneksi serial
ser = serial.Serial('COMx', 9600)  # Ganti 'COMx' dengan port serial yang sesuai

# Fungsi untuk mengirim perintah ke robot
def send_command(command):
    ser.write(command.encode())

# Contoh penggunaan
send_command("MOVE_FORWARD")

# Tutup koneksi serial
ser.close()
